<?php
/*
Plugin Name: Hyper Plugin
Plugin URI: http://example.com/
Description: これはハイパープラグインです。
Version: 1.0
Author: Nakashima
Author URI: http://example.com/
License: GPLv2 or later
*/
